// WiFi credentials
const char *ssid = "ucll-integratieproject";
const char *password = "aesheiSei8uaMiag";

// const char *ssid = "Mahdi";
// const char *password = "mahdi123";
// const char *ssid = "telenet-6640301";
// const char *password = "s3rfbbdkjnrR";



// UTC offset in seconds
const long utcOffsetInSeconds = 3600;


const char* websocket_host = "carservice-itip-project28.apps.okd.ucll.cloud";
const uint16_t websocket_port = 443;
const char* websocket_path = "/socket.io/?EIO=4";

// const char* websocket_host = "192.168.0.193";
// const uint16_t websocket_port = 3000;
// const char* websocket_path = "/socket.io/?EIO=4";