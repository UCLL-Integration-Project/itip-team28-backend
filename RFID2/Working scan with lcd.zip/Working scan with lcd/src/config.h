#ifndef CONFIG_H
#define CONFIG_H

// WiFi credentials
const char *ssid = "ucll-integratieproject";
const char *password = "aesheiSei8uaMiag";

// UTC offset in seconds (UTC+1 = 3600)
const long utcOffsetInSeconds = 3600;

// WebSocket (voor RFID data)
const char *websocket_host = "carservice-itip-project28.apps.okd.ucll.cloud";
const uint16_t websocket_port = 443;
const char *websocket_path = "/socket.io/?EIO=4";

// HTTP Backend (voor reader config ophalen)
const char *backendUrl = "https://itip-team28-backend-itip-project28.apps.okd.ucll.cloud";
#endif
