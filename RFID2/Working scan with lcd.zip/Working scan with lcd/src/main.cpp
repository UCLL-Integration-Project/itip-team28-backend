#include <ArduinoJson.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <Wire.h>
#include <MFRC522.h>
#include <SPI.h>
#include <HTTPClient.h>
#include <NTPClient.h>
#include <SocketIOclient.h>
#include <WebSocketsClient.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#include "config.h"

// Pins & modules
#define NSS_PIN 15
#define RST_PIN 5
#define GREEN_PIN 13
#define ORANGE_PIN 12
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

MFRC522 mfrc522(NSS_PIN, RST_PIN);
SocketIOclient socketIO;
WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "pool.ntp.org", utcOffsetInSeconds);
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Variables
String lastCardUID;
String currentName = "Reader";
unsigned long lastScanTime = 0;
unsigned long lastConfigFetchTime = 0;
const unsigned long scanInterval = 3000;
const unsigned long CONFIG_FETCH_INTERVAL = 5000;

// Utils
String getUIDString(byte *buffer, byte bufferSize)
{
  String uid = "";
  for (byte i = 0; i < bufferSize; i++)
  {
    if (buffer[i] < 0x10)
      uid += "0";
    uid += String(buffer[i], HEX);
  }
  uid.toUpperCase();
  return uid;
}

String getMacAddress()
{
  uint8_t mac[6];
  WiFi.macAddress(mac);
  char macStr[18];
  sprintf(macStr, "%02X:%02X:%02X:%02X:%02X:%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  return String(macStr);
}

String getISO8601Timestamp()
{
  timeClient.update();
  time_t epochTime = timeClient.getEpochTime();
  struct tm *ptm = gmtime((time_t *)&epochTime);
  char buffer[25];
  sprintf(buffer, "%04d-%02d-%02dT%02d:%02d:%02dZ",
          ptm->tm_year + 1900, ptm->tm_mon + 1, ptm->tm_mday,
          ptm->tm_hour + 1, ptm->tm_min, ptm->tm_sec);
  return String(buffer);
}

void displayInfo()
{
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.print("Reader: ");
  display.println(currentName.length() > 16 ? currentName.substring(0, 16) : currentName);
  display.display();
}

void sendData(String uid, String mac, String timestamp)
{
  Serial.println("[INFO] Versturen van data...");
  Serial.println("  UID: " + uid);
  Serial.println("  MAC: " + mac);
  Serial.println("  Timestamp: " + timestamp);

  digitalWrite(ORANGE_PIN, HIGH);
  DynamicJsonDocument doc(256);
  JsonArray array = doc.to<JsonArray>();
  array.add("update");
  JsonObject data = array.createNestedObject();
  data["car_id"] = uid;
  data["reader_id"] = mac;
  data["timestamp"] = timestamp;
  String output;
  serializeJson(doc, output);

  Serial.print("[WEBSOCKET] Verzonden payload: ");
  Serial.println(output);

  socketIO.sendEVENT(output);
  delay(300);
  digitalWrite(ORANGE_PIN, LOW);
}

void socketIOEvent(socketIOmessageType_t type, uint8_t *payload, size_t length)
{
  if (type == sIOtype_CONNECT)
  {
    Serial.println("[WEBSOCKET] Verbonden met server");
    socketIO.send(sIOtype_CONNECT, "/");
  }
  else if (type == sIOtype_DISCONNECT)
  {
    Serial.println("[WEBSOCKET] Verbinding verbroken, opnieuw verbinden...");
    socketIO.beginSSL(websocket_host, websocket_port, websocket_path);
  }
}

bool fetchReaderConfig()
{
  if (WiFi.status() != WL_CONNECTED)
  {
    Serial.println("[CONFIG] Geen WiFi verbinding");
    return false;
  }

  HTTPClient http;
  String url = String(backendUrl) + "/readers/config?mac=" + getMacAddress();
  Serial.println("[CONFIG] Ophalen readerconfig van: " + url);

  if (!http.begin(url))
  {
    Serial.println("[CONFIG] Fout bij HTTP verbinding");
    return false;
  }

  int httpCode = http.GET();
  if (httpCode == 200)
  {
    String payload = http.getString();
    Serial.println("[CONFIG] Ontvangen naam: " + payload);
    if (payload != currentName)
    {
      currentName = payload;
      displayInfo();
      Serial.println("[CONFIG] Reader naam bijgewerkt naar: " + currentName);
    }
    http.end();
    return true;
  }
  else
  {
    Serial.printf("[CONFIG] HTTP foutcode: %d\n", httpCode);
  }

  http.end();
  return false;
}

void setup()
{
  Serial.begin(115200);
  pinMode(ORANGE_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);

  SPI.begin();
  mfrc522.PCD_Init();

  Serial.println("[SETUP] Initialiseren van OLED...");
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C))
  {
    Serial.println("[FOUT] OLED initialisatie mislukt!");
    while (true)
      ;
  }

  Serial.println("[WIFI] Verbinden met netwerk...");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\n[WIFI] Verbonden!");
  Serial.println("IP-adres: " + WiFi.localIP().toString());
  digitalWrite(GREEN_PIN, HIGH);

  displayInfo();

  Serial.println("[NTP] Start tijdsynchronisatie");
  timeClient.begin();

  Serial.println("[WEBSOCKET] Verbinden met WebSocket...");
  socketIO.beginSSL(websocket_host, websocket_port, websocket_path);
  socketIO.onEvent(socketIOEvent);
}

void loop()
{
  socketIO.loop();

  unsigned long now = millis();

  // RFID scanning
  if (now - lastScanTime > scanInterval)
  {
    if (mfrc522.PICC_IsNewCardPresent() && mfrc522.PICC_ReadCardSerial())
    {
      String newUID = getUIDString(mfrc522.uid.uidByte, mfrc522.uid.size);
      Serial.println("[RFID] Kaart gescand met UID: " + newUID);
      sendData(newUID, getMacAddress(), getISO8601Timestamp());
      mfrc522.PICC_HaltA();
      lastScanTime = now;
    }
  }

  // Fetch config
  if (WiFi.status() == WL_CONNECTED && now - lastConfigFetchTime > CONFIG_FETCH_INTERVAL)
  {
    lastConfigFetchTime = now;
    fetchReaderConfig();
  }
}
