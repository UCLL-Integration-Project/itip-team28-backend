#include <WiFi.h>
#include <MFRC522.h>
#include <SPI.h>
#include <HTTPClient.h>
#include <NTPClient.h>
#include <WiFiUdp.h>

#include "config.h"

WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "pool.ntp.org", utcOffsetInSeconds);

#define SS_PIN 15
#define RST_PIN 5
MFRC522 mfrc522(SS_PIN, RST_PIN);

String lastCardUID;

String getUIDString(byte *buffer, byte bufferSize)
{
  String uid = "";
  for (byte i = 0; i < bufferSize; i++)
  {
    if (buffer[i] < 0x10)
      uid += "0";
    uid += String(buffer[i], HEX);
  }
  uid.toUpperCase();
  return uid;
}

String getMacAddress()
{
  uint8_t mac[6];
  WiFi.macAddress(mac);
  char macStr[18];
  sprintf(macStr, "%02X:%02X:%02X:%02X:%02X:%02X",
          mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  return String(macStr);
}

String getISO8601Timestamp()
{
  timeClient.update();
  time_t epochTime = timeClient.getEpochTime();
  struct tm *ptm = gmtime((time_t *)&epochTime);
  char buffer[25];
  sprintf(buffer, "%04d-%02d-%02dT%02d:%02d:%02dZ",
          ptm->tm_year + 1900,
          ptm->tm_mon + 1,
          ptm->tm_mday,
          ptm->tm_hour,
          ptm->tm_min,
          ptm->tm_sec);
  return String(buffer);
}

void sendData(String uid, String mac, String timestamp)
{
  if (WiFi.status() == WL_CONNECTED)
  {
    HTTPClient http;
    http.begin(serverURL);
    http.addHeader("Content-Type", "application/json");

    // JSON body
    String jsonBody = "{";
    jsonBody += "\"car_id\":\"" + uid + "\",";
    jsonBody += "\"reader_id\":\"" + mac + "\",";
    jsonBody += "\"timestamp\":\"" + timestamp + "\"";
    jsonBody += "}";

    int responseCode = http.POST(jsonBody);

    Serial.println("📡 Gegevens verzonden naar:");
    Serial.println(serverURL);
    Serial.print("📨 JSON body: ");
    Serial.println(jsonBody);
    Serial.print("📬 Antwoord code: ");
    Serial.println(responseCode);

    http.end();
  }
  else
  {
    Serial.println("❌ Geen WiFi verbinding.");
  }
}

void setup()
{
  Serial.begin(115200);
  SPI.begin();
  mfrc522.PCD_Init();

  WiFi.disconnect(true);
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.println("🔌 Verbinden met WiFi...");

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 10000)
  {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED)
  {
    Serial.println("\n✅ Verbonden met WiFi!");
    Serial.print("📡 IP-adres: ");
    Serial.println(WiFi.localIP());
  }
  else
  {
    Serial.println("\n❌ Verbinden mislukt.");
  }

  timeClient.begin();
}

void loop()
{
  if (!mfrc522.PICC_IsNewCardPresent() || !mfrc522.PICC_ReadCardSerial())
    return;

  String newUID = getUIDString(mfrc522.uid.uidByte, mfrc522.uid.size);
  if (newUID != lastCardUID)
  {
    lastCardUID = newUID;
    String mac = getMacAddress();
    String timestamp = getISO8601Timestamp();

    Serial.println("🔍 Nieuwe kaart gescand:");
    Serial.println("UID: " + newUID);
    Serial.println("MAC: " + mac);
    Serial.println("Timestamp: " + timestamp);

    sendData(newUID, mac, timestamp);
  }

  mfrc522.PICC_HaltA();
}
