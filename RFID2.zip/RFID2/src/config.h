#ifndef CONFIG_H
#define CONFIG_H

// WiFi credentials
const char *ssid = "ucll-integratieproject";
const char *password = "aesheiSei8uaMiag";

// Backend server URL
const char *serverURL = "https://carservice-itip-project28.apps.okd.ucll.cloud/scan";

// UTC offset in seconds
const long utcOffsetInSeconds = 3600;

#endif
